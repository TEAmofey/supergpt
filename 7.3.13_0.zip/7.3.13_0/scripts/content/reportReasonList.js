// eslint-disable-next-line no-unused-vars
const reportReasonList = [
  { code: 'select', name: 'Select reason' },
  { code: 'discriminatory', name: 'Racism, sexism, homophobia, hate, or other discrimination' },
  { code: 'spam', name: 'Spam' },
  { code: 'irrelevant', name: 'Irrelevant or annoying' },
  { code: 'wrong', name: 'Wrong tag or language' },
];
